import pandas as pd
import os

files = os.listdir(os.getcwd())
files = [f for f in files if '.py' not in f]

# F1 -> thesis_MetAromatic...
# F2 -> MetAromatic_redistributable

F1_CP = [f for f in files if len(f) == 11 and 'cp' in f]  
F2_CP = [f for f in files if len(f) != 11 and 'cp' in f]
F1_RM = [f for f in files if len(f) == 11 and 'rm' in f]
F2_RM = [f for f in files if len(f) != 11 and 'rm' in f]


for i in range(0, 3):
    dfA = pd.read_csv(F1_CP[i], index_col=False).drop('Unnamed: 0', axis=1)
    dfB = pd.read_csv(F2_CP[i], index_col=False).drop('RECORD', axis=1)
    dfA['MET-THETA-CP'] = round(dfA['MET-THETA-CP'], 3)
    dfA['MET-PHI-CP'] = round(dfA['MET-PHI-CP'], 3)
    dfA['NORM'] = round(dfA['NORM'], 3)
    
    print(dfA)
    print(dfB)
    print('-' * 50)


print('=' * 50)

for i in range(0, 3):
    dfA = pd.read_csv(F1_RM[i], index_col=False).drop('Unnamed: 0', axis=1)
    dfB = pd.read_csv(F2_RM[i], index_col=False).drop('RECORD', axis=1)
    dfA['MET-THETA-RM'] = round(dfA['MET-THETA-RM'], 3)
    dfA['MET-PHI-RM'] = round(dfA['MET-PHI-RM'], 3)
    dfA['NORM'] = round(dfA['NORM'], 3)
    
    print(dfA)
    print(dfB)
    print('-' * 50)
